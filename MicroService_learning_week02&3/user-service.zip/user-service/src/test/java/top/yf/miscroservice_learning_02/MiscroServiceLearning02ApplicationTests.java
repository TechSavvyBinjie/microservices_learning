package top.yf.miscroservice_learning_02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiscroServiceLearning02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
