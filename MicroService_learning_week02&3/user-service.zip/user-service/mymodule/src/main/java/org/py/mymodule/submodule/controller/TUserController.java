package org.py.mymodule.submodule.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author author
 * @since 2025-02-28
 */
@RestController
@RequestMapping("/t-user")
public class TUserController {

}
